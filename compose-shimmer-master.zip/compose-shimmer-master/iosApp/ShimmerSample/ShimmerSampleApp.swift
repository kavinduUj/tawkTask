import SwiftUI

@main
struct ShimmerSampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

object Config {
    const val minSdk = 21
    const val targetSdk = 34
}

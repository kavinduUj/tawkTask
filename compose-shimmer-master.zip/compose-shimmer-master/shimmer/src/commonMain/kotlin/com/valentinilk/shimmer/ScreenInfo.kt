package com.valentinilk.shimmer

import androidx.compose.runtime.Composable
import androidx.compose.ui.geometry.Rect

@Composable
internal expect fun rememberWindowBounds(): Rect

import androidx.compose.ui.window.ComposeUIViewController
import com.valentinilk.shimmer.shared.App

fun MainViewController() = ComposeUIViewController { App() }
